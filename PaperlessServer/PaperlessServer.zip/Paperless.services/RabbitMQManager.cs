﻿using Paperless.rabbitmq;

namespace Paperless.services
{
    public class RabbitMQManager
    {
        private readonly IQueueConsumer _queueConsumer;
        private readonly ILogger _logger;

        RabbitMQManager(IQueueConsumer consumer, ILogger logger)
        {
            _queueConsumer = consumer;
            _logger = logger;
        }

        public void Manage()
        {
            _queueConsumer.StartReceive();
        }
    }
}
